# PiStatus

PiStatus is an application that allows you to check the status of your Raspberry Pi.
